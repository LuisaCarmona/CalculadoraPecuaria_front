import React from 'react';
import './home.css';

export default class Home extends React.Component {
  render() {
    return (
      <div>
        <h1>Hola Mundo</h1>
      </div>
    );
  }
}
